library(testthat)
library(rmapshaper)

test_check("rmapshaper")
